package curs6.teme6Polimorfism;

public interface UnitateBancara  {

    default void credit(Integer salariu) {

    }
    default void dobandaCredit(Integer dobanda){

    }
}
