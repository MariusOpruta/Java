package curs6.teme6abstract;

public abstract class UnitateBancara  {
    public abstract void credit(Integer salariu);
    public abstract void dobandaCredit(Integer dobanda);
}
