package com.itfactory.laptop;

public class main {
    public static void main(String[] args) {
        Laptop laptop1 = new Laptop();
        System.out.println("Detalii laptop: ");
        System.out.println(laptop1.Laptop());

    }
}
